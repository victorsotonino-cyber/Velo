const {
  SlashCommandBuilder,
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require("discord.js");
const config = require("../config");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Crea un ticket privado.")
    .addStringOption(o =>
      o.setName("tipo")
       .setDescription("Tipo de ticket")
       .setRequired(true)
       .addChoices(
         { name: "Soporte", value: "soporte" },
         { name: "Compras", value: "compras" },
         { name: "Reclamo", value: "reclamo" },
         { name: "Partnership", value: "partnership" }
       )
    ),

  async execute(interaction) {
    const type = interaction.options.getString("tipo");
    const safeName = `ticket-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, "");

    const existing = interaction.guild.channels.cache.find(
      c => c.name === safeName
    );

    if (existing) {
      return interaction.reply({
        content: `❌ Ya tienes un ticket: ${existing}`,
        ephemeral: true
      });
    }

    const channel = await interaction.guild.channels.create({
      name: safeName,
      type: ChannelType.GuildText,
      parent: config.channels.tickets,
      permissionOverwrites: [
        {
          id: interaction.guild.roles.everyone.id,
          deny: ["ViewChannel"]
        },
        {
          id: interaction.user.id,
          allow: ["ViewChannel", "SendMessages", "ReadMessageHistory"]
        },
        {
          id: config.roles.staff,
          allow: ["ViewChannel", "SendMessages", "ReadMessageHistory"]
        }
      ]
    });

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle("🎫 Velo Studio — Ticket")
      .setDescription(
        `Hola ${interaction.user}, tu ticket de **${type}** fue creado.\n\n` +
        "Explica tu problema y un miembro del Staff te atenderá."
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("ticket_close")
        .setLabel("Cerrar ticket")
        .setEmoji("🔒")
        .setStyle(ButtonStyle.Danger)
    );

    await channel.send({
      content: `${interaction.user} <@&${config.roles.staff}>`,
      embeds: [embed],
      components: [row]
    });

    await interaction.reply({
      content: `✅ Ticket creado: ${channel}`,
      ephemeral: true
    });
  }
};
